import{a0 as s,e as i}from"./index-CCw4GlS4.js";function o(a,r,e){const t=s(a,e?.in);return isNaN(r)?i(a,NaN):(r&&t.setDate(t.getDate()+r),t)}export{o as a};
